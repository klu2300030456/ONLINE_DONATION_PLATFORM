package com.klef.sdp.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DFRepository extends JpaRepository<DonationForm, Integer>{

}
