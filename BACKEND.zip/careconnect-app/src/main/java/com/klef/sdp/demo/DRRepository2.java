package com.klef.sdp.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DRRepository2 extends JpaRepository<DonationRequest2, Long>
{

}
